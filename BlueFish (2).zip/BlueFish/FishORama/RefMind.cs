﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;              // Required to use XNA features.
using XNAMachinationisRatio;                // Required to use the XNA Machinationis Ratio Engine general features.
using XNAMachinationisRatio.AI;             // Required to use the XNA Machinationis Ratio general AI features.
using XNAMachinationisRatio.Resource;       // Required to use the MonoGame Machinationis Ratio resource management features.

/* LERNING PILL: XNAMachinationisRatio Engine
 * XNAMachinationisRatio is an engine that allows implementing
 * simulations and games based on XNA, simplifying the use of XNA
 * and adding features not directly available in XNA.
 * XNAMachinationisRatio is a work in progress.
 * The engine works "under the hood", taking care of many features
 * of an interactive simulation automatically, thus minimizing
 * the amount of code that developers have to write.
 * 
 * In order to use the engine, the application main class (Kernel, in the
 * case of FishO'Rama) creates, initializes and stores
 * an instance of class Engine in one of its data members.
 * 
 * The classes comprised in the  XNA Machinationis Ratio engine and the
 * related functionalities can be accessed from any of your XNA project
 * source code files by adding appropriate 'using' statements at the beginning of
 * the file. 
 * 
 */

namespace FishORama
{
    /* LEARNING PILL: Token behaviors in the XNA Machinationis Ratio engine
     * Some simulation tokens may need to enact specific behaviors in order to
     * participate in the simulation. The XNA Machinationis Ratio engine
     * allows a token to enact a behavior by associating an artificial intelligence
     * mind to it. Mind objects are created from subclasses of the class AIPlayer
     * included in the engine. In order to associate a mind to a token, a new
     * mind object must be created, passing to the constructor of the mind a reference
     * of the object that must be associated with the mind. This must be done in
     * the DefaultProperties method of the token.
     * 
     * Hence, every time a new tipe of AI mind is required, a new class derived from
     * AIPlayer must be created, and an instance of it must be associated to the
     * token classes that need it.
     * 
     * Mind objects enact behaviors through the method Update (see below for further details). 
     */
    class RefMind : AIPlayer
    {
        #region Data Members

        // This mind needs to interact with the token which it possesses, 
        // since it needs to know where are the aquarium's boundaries.
        // Hence, the mind needs a "link" to the aquarium, which is why it stores in
        // an instance variable a reference to its aquarium.
        private AquariumToken mAquarium;        // Reference to the aquarium in which the creature lives.

        Random randNum = new Random();
        Boolean decide = false;
        Boolean score = false;
       float  mFacingDirectionX = 1;             // Current direction the fish is facing.
       float  mFacingDirectionY = 1;           // Current direction the fish is facing.
       float  mSpeedX = 2; // randNum.Next(1, 5); // Random Number Value
      public float  mSpeedY = 5; // speed on the y Axis at Random Number Value
       float  mFacingDirection = 1;
       float  mSpeed = 2;
        //two team
        PiranhaToken[] mTeam1;
        PiranhaToken[] mTeam2;


        #endregion

        #region Properties

        /// <summary>
        /// Set Aquarium in which the mind's behavior should be enacted.
        /// </summary>
        public AquariumToken Aquarium
        {
            set { mAquarium = value; }
        }


        #endregion

        #region Constructors

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="pToken">Token to be associated with the mind.</param>
        public RefMind(X2DToken pToken)
        {
            /* LEARNING PILL: associating a mind with a token
             * In order for a mind to control a token, it must be associated with the token.
             * This is done when the mind is constructed, using the method Possess inherited
             * from class AIPlayer.
             */
            this.Possess(pToken);               // Possess token.


        }

        #endregion
        /* LEARNING PILL: The AI update method.
        * Mind objects enact behaviors through the method Update. This method is
        * automatically invoked by the engine, periodically, 'under the hood'. This can be
        * be better understood that the engine asks to all the available AI-based tokens:
        * "Would you like to do anything at all?" And this 'asking' is done through invoking
        * the Update method of each mind available in the system. The response is the execution
        * of the Update method of each mind , and all the methods possibly triggered by Update.
        * 
        * Although the Update method could invoke other methods if needed, EVERY
        * BEHAVIOR STARTS from Update. If a behavior is not directly coded in Updated, or in
        * a method invoked by Update, then it is IGNORED.
        * 
        */

        public void setTeams(PiranhaToken[] pTeam1, PiranhaToken[] pTeam2)
        {
            //set class variables to hold these two teams

            mTeam1 = pTeam1;
 
            Console.WriteLine(mTeam1);

        }
        

        /// <summary>
        /// AI Update method.
        /// </summary>
        /// <param name="pGameTime">Game time</param>
        private void reff()
        {
               
            //if there's a NEW chicken leg 

            if(mAquarium.ChickenLeg != null)
            {
                //and no fishg have yet been activated

                //choose which fish to activate

                //and activcate them

               mTeam1[2].setActive();
            }

           
            {


                Console.WriteLine("Team 1 Go");



            }

        }

            public override void Update(ref GameTime pGameTime)
        {
            /* LEARNING PILL: This is a special method which gets called over and over again from somewhere within the FishORama framework based on Game time (A timer)
            *  the method in thoery is like a loop, but after each iteration unlike a look, it will allow you see what happened during that iteration
            *  this acts like frames of animation, so each iteration will be a new frame.  If we move the fish 1 pixel per iteration you will see that happen
            *  during 'game time'.
            */

           
               reff();
          
        }

    }
}