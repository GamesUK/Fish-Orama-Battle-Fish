﻿namespace FishORama
{
    internal class pToken
    {
    }
}