﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;              // Required to use XNA features.
using XNAMachinationisRatio;                // Required to use the XNA Machinationis Ratio Engine general features.
using XNAMachinationisRatio.AI;             // Required to use the XNA Machinationis Ratio general AI features.


namespace FishORama
{
    class PiranhaMind : AIPlayer
    {
        #region Data Members

        // This mind needs to interact with the token which it possesses, 
        // since it needs to know where are the aquarium's boundaries.
        // Hence, the mind needs a "link" to the aquarium, which is why it stores in
        // an instance variable a reference to its aquarium.
        private AquariumToken mAquarium;            // Reference to the aquarium in which the creature lives
        private PiranhaToken mToken;

        public float mFacingDirectionX = -1;        // Direction the fish is facing (1: right; -1: left).
        float mSpeedX = 2;
        float mSpeedY = 1;
        float mFacingDirectionY;
        // DATA MEMBERS FOR DASH >>>
        Random random = new Random(); // generates a random number
        double angle = 0; // sets the angle
        double radius = 25; // sets the radius 
        public Vector3 Startingposition; //sets a starting position
        bool active = false;
        private Vector3 tokenPosition;

        #endregion

        #region Properties

        /// <summary>
        /// Set Aquarium in which the mind's behavior should be enacted.
        /// </summary>
        public AquariumToken Aquarium
        {
            set { mAquarium = value; }
            
        }

        public bool Active
        {

            set { active = value; }

        }

        #endregion

        #region Constructors

        /// <summary>
        /// Default constructor.
        /// </summary>
        /// <param name="pToken">Token to be associated with the mind.</param>
        public PiranhaMind(X2DToken pToken)
        {
            /* LEARNING PILL: associating a mind with a token
             * In order for a mind to control a token, it must be associated with the token.
             * This is done when the mind is constructed, using the method Possess inherited
             * from class AIPlayer.
             */
            this.Possess(pToken);       // Possess token.

         //   mFacingDirectionX = 1;       // Current direction the fish is facing.            
        }

        #endregion



        /* LEARNING PILL: The AI update method.
         * Mind objects enact behaviors through the method Update. This method is
         * automatically invoked by the engine, periodically, 'under the hood'. This can be
         * be better understood that the engine asks to all the available AI-based tokens:
         * "Would you like to do anything at all?" And this 'asking' is done through invoking
         * the Update method of each mind available in the system. The response is the execution
         * of the Update method of each mind , and all the methods possibly triggered by Update.
         * 
         * Although the Update method could invoke other methods if needed, EVERY
         * BEHAVIOR STARTS from Update. If a behavior is not directly coded in Updated, or in
         * a method invoked by Update, then it is IGNORED.
         * 
         */

        /// <summary>
        /// AI Update method.
        /// </summary>
        /// <param name="pGameTime">Game time</param>
        

        // this is the code to make the fish swim in a circle
        /* http://www.softwareandfinance.com/CSharp/Draw_Circle_Pixel.html */
        /* this makes a circle and allow an object to go around in circles*/
        public override void Update(ref GameTime pGameTime)
        {
            //
            //if I'm the chosen fish I need to swim to the chicken leg
            //
            if (active)
            {                
                if (mFacingDirectionY <=0 || mFacingDirectionY >=2000)
                    {
                    mSpeedY *= 0;
                this.PossessedToken.Position = tokenPosition;
}
            }


            //
            //if I'm clsoe to the chicken leg I eat it. 
            //


            //other wise I swim in circles around my starting point
            else
            {
                tokenPosition.Y = tokenPosition.Y + mSpeedY * mFacingDirectionY;
       
                Vector3 tokenPos = this.PossessedToken.Position;

                //this sets the position of the teams in the opperset direction
                if (Startingposition.X < 0)
                {
                    //set mFacingDirection in one direction
                    mFacingDirectionX = -1;
                }

                else
                {
                    //set mfacing direction the other way
                    mFacingDirectionX = +1;
                }

                //angle direction for the circle of fish swiming
                angle = angle + 0.1;
                float x = Startingposition.X + (float)(radius * System.Math.Cos(angle));

                float y = Startingposition.Y + (float)(radius * System.Math.Sin(angle));
                tokenPos.X = x;
                tokenPos.Y = y;

                //CODE FOR REVERSING IMAGE HERE >>>
                if (mFacingDirectionX != 0)

                {
                    this.PossessedToken.Orientation = new Vector3(mFacingDirectionX, this.PossessedToken.Orientation.Y, this.PossessedToken.Orientation.Z);

                }

                // Set fish pos to new vector
                this.PossessedToken.Position = tokenPos;

                /* LEARNING PILL: This is a special method which gets called over and over again from somewhere within the FishORama framework based on Game time (A timer)
                *  the method in thoery is like a loop, but after each iteration unlike a look, it will allow you see what happened during that iteration
                *  this acts like frames of animation, so each iteration will be a new frame.  If we move the fish 1 pixel per iteration you will see that happen
                *  during 'game time'.
                */
            }
        }
    }
}

