﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace XNAMachinationisRatio.Rendering {
    interface I3DRenderableObject {
        Model Model { get; }
    }
}
